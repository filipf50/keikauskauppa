<?php
$_['heading_title']         = 'Play.com (EU)';
$_['lang_heading_title']    = 'OpenBay Pro for Play.com';
/* Settings tab */