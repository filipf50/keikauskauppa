<?php 
# Anything in here with the same name will overwrite the main file without underscore.  

$_['entry_template']  = 'Templates';

$_['text_unsubscribe']  = '<a href="%s">Unsubscribe</a> from our newsletter';

?>