<?php 
# Anything in here with the same name will overwrite the main file without underscore.  

$_['entry_templates']  = 'Templates';
$_['entry_summary']  = 'Summary';
$_['entry_show_summary']  = 'show return info in email';

?>