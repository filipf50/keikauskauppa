<?php 
//-----------------------------------------------------
// Newsletter Enhancements for Opencart
// Created by @DmitryNek (Dmitry Shkoliar)
// exmail.Nek@gmail.com
//-----------------------------------------------------

// Heading
$_['heading_title']							= 'Newsletter Blacklisted Emails';

// Text
$_['text_success']           				= 'Success: You have added %s emails!';
$_['text_success_delete']           		= 'Success: You have deleted selected emails!';
$_['text_add_info']							= 'Emails divided by comma or newline:';

// Column
$_['column_email']							= 'Email';
$_['column_date']							= 'Date Added';

?>
