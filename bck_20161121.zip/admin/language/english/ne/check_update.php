<?php 
//-----------------------------------------------------
// Newsletter Enhancements for Opencart
// Created by @DmitryNek (Dmitry Shkoliar)
// exmail.Nek@gmail.com
//-----------------------------------------------------

// Heading
$_['heading_title']							= 'Check For Updates';

// Text
$_['text_update_latest']					= 'Great News! You\'re running the latest version of  Newsletter Enhancements - V3 - vQmod + Free Mega Template Pack - v%s';
$_['text_update_available']					= 'A new version v%s of Newsletter Enhancements - V3 - vQmod + Free Mega Template Pack is available. Click <a href="http://www.opencart.com/index.php?route=extension/extension/info&extension_id=4776" target="_blank">here</a> to download latest version';

// Button 
$_['button_check']							= 'Check';

?>
