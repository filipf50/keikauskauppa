<?php
// Heading
$_['heading_title'] = 'Popup Newsletter Subscriber List';
$_['popupemail_email'] = 'Email';
$_['popupemail_id'] = 'Id';
$_['popupemail_fname'] = 'First Name';
$_['popupemail_lname'] = 'Last Name';
$_['popupemail_date'] = 'Date Added';
$_['popupemail_delete'] = 'Delete';
$_['popupemail_subscriber'] = 'Subscribed';
$_['popupemail_setting'] = 'Popup Setting';
$_['popupemail_unsubscriber'] = 'UnSubscribed';

?>