<?php
$_['lang_title']                    = 'OpenBay Pro for Amazon US';
$_['lang_heading']                  = 'Amazon US Overview';
$_['lang_overview']                 = 'Amazon US Overview';
$_['lang_openbay']                  = 'OpenBay Pro';
$_['lang_heading_settings']         = 'Asetukset';
$_['lang_heading_account']          = 'My Account';
$_['lang_heading_links']            = 'Item links';
$_['lang_heading_register']         = 'Rekisteri';
$_['lang_heading_stock_updates']    = 'Osakep&auml;ivitykset';
$_['lang_heading_saved_listings']   = 'Saved listings';