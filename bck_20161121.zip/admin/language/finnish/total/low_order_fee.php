<?php
// Heading
$_['heading_title']    = 'Low Order maksutapa';

// Text
$_['text_total']       = 'Tilaukset';
$_['text_success']     = 'Suorite: Asetukset on tallennettu onnistuneesti!';

// Entry
$_['entry_total']      = 'Tilaukset:';
$_['entry_fee']        = 'Fee:';
$_['entry_tax']        = 'Veroluokka:';
$_['entry_status']     = 'Tila:';
$_['entry_sort_order'] = 'J&auml;rjestysnumero:';

// Error
$_['error_permission'] = 'Varoitus: Sinulla ei ole vaadittavia oikeuksia suorittaa toimintoa!';
?>