<?php
// Text
$_['text_title']           = 'Luottokortti / Pankkikortti (SagePay)';
$_['text_credit_card']     = 'Luottokortin tiedot';
$_['text_wait']            = 'Ole hyv&auml; ja odota!';

// Entry
$_['entry_cc_owner']       = 'Kortin omistaja:';
$_['entry_cc_number']      = 'Kortin numero:';
$_['entry_cc_expire_date'] = 'Kortti voimassa (pvm):';
$_['entry_cc_cvv2']        = 'Kortin varmistetunnus (CVV2):';
?>