<?php
// Text
$_['text_title'] = 'Luottokortti / Pankkikortti (Authorize.Net)';
?>