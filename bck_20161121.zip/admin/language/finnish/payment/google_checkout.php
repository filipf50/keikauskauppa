<?php
// Entry
$_['entry_postcode'] = 'Postinumero:';
$_['entry_country']  = 'Maa:';
$_['entry_zone']     = 'Alue / Maakunta:';
?>