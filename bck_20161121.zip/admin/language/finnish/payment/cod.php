<?php
// Heading
$_['heading_title']      = 'J&auml;lkivaatimus';

// Text
$_['text_payment']       = 'Maksutavat';
$_['text_success']       = 'Suorite: Asetukset on tallennettu onnistuneesti!';

// Entry
$_['entry_total'] = 'Yhteens&auml;:';
$_['entry_order_status'] = 'Tilauksen tilanne:';
$_['entry_geo_zone']     = 'Maantiet. alue:';
$_['entry_status']       = 'Tila:';
$_['entry_sort_order']   = 'J&auml;rjestysnumero:';

// Error
$_['error_permission']   = 'Varoitus: Sinulla ei ole vaadittavia oikeuksia suorittaa toimintoa!';
?>