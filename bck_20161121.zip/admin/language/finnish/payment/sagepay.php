<?php
// Text
$_['text_title']       = 'Luottokortti / Pankkikortti (SagePay)';
$_['text_description'] = 'Items on %s Order No: %s';
?>