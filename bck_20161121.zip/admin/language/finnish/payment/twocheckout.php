<?php
// Text
$_['text_title'] = 'Luottokortti / Pankkikortti (2Checkout)';
?>