<?php
// Heading
$_['heading_title']     = 'Sopimusasiakkaiden provisioraportit';

// Column
$_['column_affiliate']  = 'Sopimusasiakas';
$_['column_email']      = 'S&auml;hk&ouml;postiosoite';
$_['column_status']     = 'Tila';
$_['column_commission'] = 'Provisiot';
$_['column_orders']     = 'Tilaukset';
$_['column_total']      = 'Yhteens&auml';
$_['column_action']     = 'Toiminta';

// Entry
$_['entry_date_start']    = 'Alkaen (pvm):';
$_['entry_date_end']      = 'Asti (pvm):';
?>