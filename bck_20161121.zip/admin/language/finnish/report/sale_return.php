<?php

$_['heading_title'] = 'Palautusraportti';
$_['text_year'] = 'Vuotta';
$_['text_month'] = 'Kuukautta';
$_['text_week'] = 'Viikkoa';
$_['text_day'] = 'P&auml;iv&auml;&auml;';
$_['text_all_status'] = 'Kaikki tilat';
$_['column_date_start'] = 'Pvm alkaa';
$_['column_date_end'] = 'Pvm loppuu';
$_['column_returns'] = 'No. palautukset';
$_['column_products'] = 'No. Tuotteet';
$_['entry_date_start']    = 'Alkaen (pvm):';
$_['entry_date_end']      = 'Asti (pvm):';
$_['entry_group'] = 'Ryhmit&auml;:';
$_['entry_status'] = 'Palautuksen tila:';

?>