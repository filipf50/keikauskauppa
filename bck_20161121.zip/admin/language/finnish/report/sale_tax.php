<?php

$_['heading_title'] = 'Vero raportti';
$_['text_year'] = 'Vuotta';
$_['text_month'] = 'Kuukautta';
$_['text_week'] = 'Viikkoa';
$_['text_day'] = 'P&auml;iv&auml;&auml;';
$_['text_all_status'] = 'Kaikki tilat';
$_['column_date_start'] = 'Pvm alkaa';
$_['column_date_end'] = 'Pvm loppuu';
$_['column_title'] = 'Vero otsikko';
$_['column_orders'] = 'Tilaukset';
$_['column_total'] = 'Yhteens&auml;';
$_['entry_date_start']    = 'Alkaen (pvm):';
$_['entry_date_end']      = 'Asti (pvm):';
$_['entry_group'] = 'Ryhmit&auml;:';
$_['entry_status'] = 'Tilauksen tilanne:';

?>