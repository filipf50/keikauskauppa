<?php

$_['heading_title'] = 'Tuotetta katsottu raportti';
$_['text_success'] = 'Suorite: Tuoteraportti on nollattu!';
$_['column_name'] = 'Tuotteen nimi';
$_['column_model'] = 'Malli';
$_['column_viewed'] = 'Katsottu';
$_['column_percent'] = 'Prosenttia';

?>