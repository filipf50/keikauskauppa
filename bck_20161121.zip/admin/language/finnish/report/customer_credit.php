<?php

$_['heading_title'] = 'Asiakkaan krediitti raportti';
$_['column_customer'] = 'Asiakkaan nimi';
$_['column_email'] = 'S&auml;hk&ouml;postiosoite';
$_['column_customer_group'] = 'Asiakasryhm&auml;';
$_['column_status'] = 'Tila';
$_['column_total'] = 'Yhteens&auml;';
$_['column_action'] = 'Toimenpide';
$_['entry_date_start']    = 'Alkaen (pvm):';
$_['entry_date_end']      = 'Asti (pvm):';

?>