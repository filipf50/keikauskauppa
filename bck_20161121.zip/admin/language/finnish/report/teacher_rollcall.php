<?php
// Heading
$_['heading_title']     = 'Teachers Rollcall';

// Text
$_['text_all_status']   = 'All Statuses';

// Column
$_['column_order']          = 'Order N.';
$_['column_status']         = 'Status';
$_['column_date_added']     = 'Date Added';
$_['column_product_name']   = 'Product Name';
$_['column_email']          = 'E-mail';
$_['column_phone']          = 'Phone';
$_['column_model']          = 'Model';
$_['column_option']         = 'Option';
$_['column_value']          =  'Value';
$_['column_assist']          =  'Assist';

// Entry
$_['entry_product_name']    = 'Product Name:';
$_['entry_model']           = 'Model:';
$_['entry_option']           = 'Tilauksen vaihtoehto:';
$_['entry_status']          = 'Order Status:';
$_['entry_roll_date']          = 'Roll date:';

//Button
$_['button_excel']          ="Export to Excel";
?>