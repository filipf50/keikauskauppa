<?php

$_['heading_title'] = 'Tuote ostettu  raportti';
$_['text_all_status'] = 'Kaikki tilat';
$_['column_date_start'] = 'Pvm alkaa';
$_['column_date_end'] = 'Pvm loppuu';
$_['column_name'] = 'Tuotteen nimi';
$_['column_model'] = 'Malli';
$_['column_quantity'] = 'M&auml;&auml;r&auml;';
$_['column_total'] = 'Yhteens&auml;';
$_['entry_date_start']    = 'Alkaen (pvm):';
$_['entry_date_end']      = 'Asti (pvm):';
$_['entry_status'] = 'Tilauksen tilanne:';

?>