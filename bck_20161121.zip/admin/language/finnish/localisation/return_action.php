<?php

$_['heading_title'] = 'Palautuksien toimenpiteet';
$_['text_success'] = 'Suorite: Palautuksen toimenpiteiden muokkaus onnistui!';
$_['column_name'] = 'Palautuksien toimenpiteet nimi:';
$_['column_action'] = 'Toimenpide';
$_['entry_name'] = 'Palautuksien toimenpiteet nimi:';
$_['error_permission'] = 'Varoitus: Sinulla ei ole vaadittavia oikeuksia suorittaa toimintoa!';
$_['error_name'] = 'Palautuksien toimenpiteet nimen on oltava 3-32 merkki&auml; pitk&auml;!';
$_['error_return'] = 'Varoitus: Valittua palautusta ei voida poistaa koska se on kiinni %s palautetussa tuotteessa!';

?>