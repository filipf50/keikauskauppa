<?php

$_['heading_title'] = 'Palautuksen tila';
$_['text_success'] = 'Suorite: Palautus onnistui!';
$_['column_name'] = 'Palautuksen tila nimi:';
$_['column_action'] = 'Toimenpide';
$_['entry_name'] = 'Palautuksen tila nimi:';
$_['error_permission'] = 'Varoitus: Sinulla ei ole vaadittavia oikeuksia suorittaa toimintoa!';
$_['error_name'] = 'Return Status Name must be between 3 and 32 characters!';
$_['error_default'] = 'Warning: This return status cannot be deleted as it is currently assigned as the default return status!';
$_['error_return'] = 'Warning: This return status cannot be deleted as it is currently assigned to %s returns!';

?>