<?php

$_['heading_title'] = 'Atribuutit';
$_['text_success'] = 'Suorite: Olet muokannut atribuutteja!';
$_['column_name'] = 'Atribuutin nimi';
$_['column_attribute_group'] = 'Atribuutin ryhm&auml;';
$_['column_sort_order'] = 'J&auml;rjestys';
$_['column_action'] = 'Toiminta';
$_['entry_name'] = 'Atribuutin nimi:';
$_['entry_attribute_group'] = 'Atribuutin ryhm&auml;:';
$_['entry_sort_order'] = 'J&auml;rjestysnumero:';
$_['error_permission'] = 'Varoitus: Sinulla ei ole vaadittavia oikeuksia suorittaa toimintoa!';
$_['error_name'] = 'Atribuutin nimi -sy&ouml;tteen on oltava 3 - 64 merkki&auml; pitk&auml;!';
$_['error_product'] = 'Varoitus: Valittua atribuuttia ei voi poistaa koska se on k&auml;ytt&ouml;ss&auml; %s tuotteessa!';

?>