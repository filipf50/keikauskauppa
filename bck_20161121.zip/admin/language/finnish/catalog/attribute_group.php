<?php

$_['heading_title'] = 'Atribuuttiryhm&auml;t';
$_['text_success'] = 'Suorite: Olet muokannut atribuuttiryhmi&auml;!';
$_['column_name'] = 'Atribuuttiryhm&auml;n nimi';
$_['column_sort_order'] = 'J&auml;rjestys';
$_['column_action'] = 'Toiminta';
$_['entry_name'] = 'Atribuuttiryhm&auml;n nimi:';
$_['entry_sort_order'] = 'J&auml;rjestysnumero:';
$_['error_permission'] = 'Varoitus: Sinulla ei ole vaadittavia oikeuksia suorittaa toimintoa!';
$_['error_name'] = 'Atribuuttiryhm&auml;n nimi -sy&ouml;tteen on oltava 3 - 64 merkki&auml; pitk&auml;!';
$_['error_attribute'] = 'Varoitus: Valittua atribuuttiryhm&auml;&auml; ei voi poistaa koska se on k&auml;yt&ouml;ss&auml; %s atribuutissa!';
$_['error_product'] = 'Varoitus: Valittua atribuuttiryhm&auml;&auml; ei voi poistaa koska se on k&auml;yt&ouml;ss&auml; %s tuotteessa!';

?>