<?php 
$_['heading_title']                     = 'eBay';
$_['text_edit']                         = 'Muokkaa';
$_['text_install']                      = 'Asenna';
$_['text_uninstall']                    = 'Poista';
$_['text_enabled']                      = 'K&auml;yt&ouml;ss&auml;';
$_['text_disabled']                     = 'Ei k&auml;yt&ouml;ss&auml;';
$_['error_category_nosuggestions']      = 'Could not load any suggested categories';
$_['lang_text_success']                 = 'You have saved your changes to the eBay extension';