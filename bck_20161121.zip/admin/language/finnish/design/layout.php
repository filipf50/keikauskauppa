<?php

$_['heading_title'] = 'Layoutit';
$_['text_success'] = 'Suorite: Olet muokannut layoutteja!';
$_['text_default'] = 'Oletus';
$_['column_name'] = 'Layoutin Nimi';
$_['column_action'] = 'Toiminta';
$_['entry_name'] = 'Layoutin Nimi:';
$_['entry_store'] = 'Kauppa:';
$_['entry_route'] = 'Reitti:';
$_['error_permission'] = 'Varoitus: Sinulla ei ole vaadittavia oikeuksia suorittaa toimintoa!';
$_['error_name'] = 'Layoutin nimen on oltava 3-64 merkki&auml; pitk&auml;!';
$_['error_default'] = 'Varoitus: Valittua layoutia ei voi juuri nyt poistaa koska se on kaupan oletus layout!';
$_['error_store'] = 'Varoitus: Valittua layoutia ei voi poistaa koska se on k&auml;yt&ouml;ss&auml; %s kaupassa!';
$_['error_product'] = 'Varoitus: Valittua layoutia ei voi poistaa koska se on k&auml;yt&ouml;ss&auml; %s tuotteessa!';
$_['error_category'] = 'Varoitus: Valittua layoutia ei voi poistaa koska se on k&auml;yt&ouml;ss&auml; %s kategoriaan!';
$_['error_information'] = 'Varoitus: Valittua layoutia ei voi poistaa koska se on k&auml;yt&ouml;ss&auml; %s informaatio sivuilla!';

?>