<?php

$_['heading_title'] = 'Bannerit';
$_['text_success'] = 'Suorite: Olet muokannut bannereita!';
$_['text_default'] = 'Oletus';
$_['text_image_manager'] = 'Kuvamanageri';
$_['text_browse'] = 'Selaa tiedostoja';
$_['text_clear'] = 'Poista kuva';
$_['column_name'] = 'Bannerin nimi';
$_['column_status'] = 'Tila';
$_['column_action'] = 'Toiminta';
$_['entry_name'] = 'Bannerin nimi:';
$_['entry_title'] = 'Otsikko:';
$_['entry_link'] = 'Linkki:';
$_['entry_image'] = 'Kuva:';
$_['entry_status'] = 'Tila:';
$_['error_permission'] = 'Varoitus: Sinulla ei ole vaadittavia oikeuksia suorittaa toimintoa!';
$_['error_name'] = 'Bannerin nimen on oltava 3-64 merkki&auml; pitk&auml;!';
$_['error_title'] = 'Bannerin otsikon on oltava 2-64 merkki&auml; pitk&auml;!';
$_['error_default'] = 'Varoitus: Valittua layoutia ei voi poistaa koska se on k&auml;yt&ouml;ss&auml; kaupan oletus layoutina!';
$_['error_product'] = 'Varoitus: Valittua layoutia ei voi poistaa koska se on k&auml;yt&ouml;ss&auml; %s tuotteessa!';
$_['error_category'] = 'Varoitus: Valittua layoutia ei voi poistaa koska se on k&auml;yt&ouml;ss&auml;  %s kategoriassa!';
$_['error_information'] = 'Varoitus:  Valittua layoutia ei voi poistaa koska se on k&auml;yt&ouml;ss&auml;  %s informaatio sivuilla!';

?>