<?php
// Heading
$_['heading_title']      = 'Postipaketti';

// Text
$_['text_shipping']      = 'Toimitustavat';
$_['text_success']       = 'Suorite: Asetukset on tallennettu onnistuneesti!';

// Entry
$_['entry_rate']         = 'Hinnat:<br /><span class="help">Esim: 5:10.00,7:12.00 Paino:Hinta,Paino:Hinta, jne..</span>';
$_['entry_tax']          = 'Veroluokka:';
$_['entry_geo_zone']     = 'Maantiet. alue:';
$_['entry_status']       = 'Tila:';
$_['entry_sort_order']   = 'J&auml;rjestysnumero:';

// Error
$_['error_permission']   = 'Varoitus: Sinulla ei ole vaadittavia oikeuksia suorittaa toimintoa!';
?>