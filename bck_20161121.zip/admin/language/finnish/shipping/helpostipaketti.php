﻿<?php
// Heading
$_['heading_title']    = 'Helposti-paketti';

// Text
$_['text_shipping']    = 'Toimitustavat';
$_['text_success']     = 'Suorite: Asetukset on tallennettu onnistuneesti!';

// Entry
$_['entry_cost']       = 'Hinta:';
$_['entry_tax']        = 'Veroluokka:';
$_['entry_geo_zone']   = 'Maantiet. alue:';
$_['entry_status']     = 'Tila:';
$_['entry_sort_order'] = 'J&auml;rjestysnumero:';

// Error
$_['error_permission'] = 'Varoitus: Sinulla ei ole vaadittavia oikeuksia suorittaa toimintoa!';
?>