<?php
$_['lang_openbay_new']              = 'Luo uusi listaus';
$_['lang_openbay_edit']             = 'N&auml;yt&auml; / Muokkaa listausta';
$_['lang_openbay_fix']              = 'Korjaa';
$_['lang_openbay_processing']       = 'K&auml;sitelt&auml;v&auml;n&auml;';

$_['lang_amazonus_saved']           = 'Tallennettu (ei ladattu)';
$_['lang_amazon_saved']             = 'Tallennettu (ei ladattu)';
$_['lang_play_pending_new']         = 'Avoin (uusi)';
$_['lang_play_pending_updated']     = 'Avoin (p&auml;ivitetty)';
$_['lang_play_warning']             = 'Varoitusviestit';
$_['lang_play_pending_delete']      = 'Keskeyt&auml;';
$_['lang_play_stock_updating']      = 'Varasto p&auml;ivitys';

$_['lang_markets']                  = 'Markkinat';
$_['lang_bulk_btn']                 = 'eBay bulk upload';

$_['lang_marketplace']              = 'Markkinapaikka';
$_['lang_status']                   = 'Tila';
$_['lang_option']                   = 'Vaihtoehto';