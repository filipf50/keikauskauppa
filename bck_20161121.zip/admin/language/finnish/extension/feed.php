<?php
// Heading
$_['heading_title']      = 'Tuotesy&ouml;tteet';

// Text
$_['text_install']       = 'Asenna';
$_['text_uninstall']     = 'Poista';

// Column
$_['column_name']        = 'Tuotesy&ouml;tteen nimi';
$_['column_status']      = 'Tila';
$_['column_action']      = 'Toimenpide';
$_['column_development'] = 'Kehityksen tila';

?>