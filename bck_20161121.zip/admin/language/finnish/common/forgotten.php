<?php

$_['heading_title'] = 'Unohtuiko salasana?';
$_['text_forgotten'] = 'Salasana unohtunut';
$_['text_your_email'] = 'Email-osoitteesi';
$_['text_email'] = 'Anna email-osoitteesi. Klikkaa l&auml;het&auml; niin uusi salasana l&auml;hetet&auml;&auml;n antamaasi s&auml;hk&ouml;postiosoitteeseen.';
$_['text_success'] = 'Suorite: Viesti vahvistuslinkin kera on l&auml;hetetty s&auml;hk&ouml;postiisi.';
$_['entry_email'] = 'E-Mail Osoite:';
$_['entry_password'] = 'Uusi salasana:';
$_['entry_confirm'] = 'Vahvista:';
$_['error_email'] = 'Varoitus: S&auml;hk&ouml;postiosoitetta ei l&ouml;ytynyt tiedoistamme, yrit&auml; uudelleen!';
$_['error_password'] = 'Salasanan on oltava 4 - 20 merkki&auml; pitk&auml;!';
$_['error_confirm'] = 'Salasanan vahvistus ei vastaa salasanaa!';

?>