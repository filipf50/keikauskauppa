<?php
// Heading
$_['heading_title']          = 'Tuotteen Tarjoukset Wizard'; 

//TEXT
$_['text_module'] = 'Moduulit';
$_['text_success'] = 'Tarjoukset on lisätty% tuotteista onnistuneesti!';
$_['text_deleted'] = 'Tarjoukset on poistettu %s tuotteista onnistuneesti!';

// Entry
$_['entry_customer_group']             = 'Asiakasryhmä:';
$_['entry_free_days']            = 'Vapaa päivä:';
$_['entry_products']            = 'Tuotteet:<br /><span class="help">Se tuottaa erikoisuuksia hinnat<br /> Valittujen tuotteiden.</span>';

//Button
$_['button_generate']  = 'Luo ja Tallenna';
$_['button_delete']  = 'Poista tarjouksesta';
?>