<?php
// Heading
$_['heading_title'] = 'Virheloki';

// Text
$_['text_success'] = 'Suorite: Lokin tyhjennys on suoritetu onnistuneesti!';
?>