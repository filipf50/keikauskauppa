<?php
// Heading
$_['heading_title']    = 'Varmistus/Palautus';

// Text
$_['text_backup']      = 'Lataa varmuuskopio';
$_['text_success']     = 'Suorite: Tietokanta on palautettu onnistuneesti!';

// Entry
$_['entry_restore']    = 'Palauta varmuuskopio:';
$_['entry_backup']     = 'Varmuuskopioi seuraavat:';

// Error
$_['error_permission'] = 'Varoitus: Sinulla ei ole vaadittavia oikeuksia suorittaa toimintoa!';
$_['error_empty']      = 'Varoitus: Tiedosto on tyhj&auml;!';
?>