<?php

$_['heading_title'] = 'Lahjakortin teemat';
$_['text_success'] = 'Suorite: Asetukset on tallennettu onnistuneesti!';
$_['text_image_manager'] = 'Kuvamanageri';
$_['text_browse'] = 'Selaa tiedostoja';
$_['text_clear'] = 'Tyhjenn&auml; kuva';
$_['column_name'] = 'Lahjakortin teeman nimi';
$_['column_action'] = 'Toiminta';
$_['entry_name'] = 'Lahjakortin teeman nimi:';
$_['entry_description'] = 'Lahjakortin teeman kuvaus:';
$_['entry_image'] = 'Kuva:';
$_['error_permission'] = 'Varoitus: Sinulla ei ole vaadittavia oikeuksia suorittaa toimintoa!';
$_['error_name'] = 'Voucher Theme Name must be between 3 and 32 characters!';
$_['error_image'] = 'Kuva-sy&ouml;te on pakollinen!';
$_['error_voucher'] = 'Warning: This voucher theme cannot be deleted as it is currently assigned to %s vouchers!';

?>