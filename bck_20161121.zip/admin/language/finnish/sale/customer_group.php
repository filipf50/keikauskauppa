<?php

$_['heading_title'] = 'Asiakasryhm&auml;t';
$_['text_success'] = 'Suorite: Asetukset on tallennettu onnistuneesti!';
$_['column_name'] = 'Asiakasryhm&auml;n nimi';
$_['column_action'] = 'Toimenpide';
$_['entry_name'] = 'Asiakasryhm&auml;n nimi:';
$_['error_permission'] = 'Varoitus: Sinulla ei ole vaadittavia oikeuksia suorittaa toimintoa!';
$_['error_name'] = 'Asiakasryhm&auml;n nimen on oltava 3-64 merkki&auml; pitk&auml;!';
$_['error_default'] = 'Varoitus: Valittua asiakasryhm&auml;&auml; ei voi poistaa, koska se on oletusasiakasryhm&auml;!';
$_['error_store'] = 'Varoitus: Valittua asiakasryhm&auml;&auml; ei voi poistaa, koska se on k&auml;yt&ouml;ss&auml;%s kaupassa!';
$_['error_customer'] = 'Varoitus: Valittua asiakasryhm&auml;&auml; ei voi poistaa, koska se on liitetty %s asiakkaaseen!';

?>