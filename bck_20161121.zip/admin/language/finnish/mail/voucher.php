<?php

$_['text_subject'] = 'Olet saanut lahjakortin henkil&ouml;lt&auml;%s';
$_['text_greeting'] = 'Onneksi olkoon! olet saanut lahjakortin, joka on arvoltaan %s';
$_['text_from'] = 'T&auml;m&auml;n lahjakortin sinulle l&auml;hetti %s';
$_['text_message'] = 'Viestin kera jossa lukee';
$_['text_redeem'] = 'Lunastaaksesi t&auml;m&auml;n lahjakortin, kirjoita yl&ouml;s koodi joka on <b>%s</b> sitten klikkaa alla olevaa linkki&auml; ja osta se tuote johon t&auml;m&auml;n lahjakortin haluat k&auml;ytt&auml;&auml;. Voit antaa t&auml;m&auml;n koodin siin&auml; vaiheessa kun olet klikannut checkout-kohtaa.';
$_['text_footer'] = 'Vastaa t&auml;h&auml;n viestiin jos sinulla on kysytt&auml;v&auml;&auml;.';

?>