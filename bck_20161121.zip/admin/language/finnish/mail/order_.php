<?php
# Anything in here with the same name will overwrite the main file without underscore. 

$_['text_download']           = 'Lataukset'; 
$_['text_model']              = 'Malli'; 
$_['text_order']              = 'Tilaus ID:'; 
$_['text_price']              = 'Hinta'; 
$_['text_product']            = 'Tuote'; 
$_['text_total']              = 'Yhteensä'; 
$_['text_link']              = 'Voit tarkistaa tilauksesi täältä:'; 


?>