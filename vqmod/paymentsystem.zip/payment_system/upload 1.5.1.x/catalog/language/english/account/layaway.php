<?php

$_['text_customer_subject']		= 'Your %s Order # %s from %s';
$_['text_customer_message']		= 'This notification is to inform you that %s order # %s is currently past the agreed upon %s payment date
								   which is set at %s days.  Please contact the store to arrange final payment.';
								   
$_['text_store_subject']		= 'Customer %s Order # %s from %s';
$_['text_store_message']		= 'This notification is to inform you that %s order # %s is currently past the agreed upon %s payment
								   date.  The customer has been notified and asked to contact the store for final payment.';

?>