Install phpMailer
===============================
WHAT: Upgrading the standard Opencart Mail with phpMailer.
WHY: Because there are a number of different issues with standard Opencart Mail with certain hosts.
	 Also phpMailer is far superior with the ability to add domain keys or DKIM to the headers AKA sending the email correctly and decreases the chance of being marked as SPAM.

INSTALL:
1. Upload all of the files (no files are overwritten)
2. For this to work correctly you need to set this up with an email account instead of PHP mail()
		
	As an example we can use google mail settings:
	Mail Protocol: SMTP
	SMTP Host: smtp.gmail.com (OR smtp.mymail.server)
	SMTP Username: myemail@gmail.com
	SMTP Password: password
	SMTP Port: 465 (465=SSL // 587=TLS // 25=SMTP standard)
			
	Note:
	- For SSL you may need to enable extension: php_openssl
	- There is no guarantee this will work with your email hosting provider, depending if they allow remote emails to be sent.

CREDITS:
@Xsecrets - http://www.opencart.com/index.php?route=extension/extension/info&extension_id=3932
	- very simular apart from upgraded phpMailer, improved the vqmod to make it more flexible and added debugMode for easy debugging.
@SubCon - http://forum.opencart.com/viewtopic.php?t=6301
Carl.F - http://www.sandersonassociates.co.uk

SUPPORT: NO support is provided if this doesn't work on your host, you need to contact your host to check if you are allowed to send SMTP emails and the settings they suggest. 

LINKS:
PHPMailer Homepage: http://phpmailer.sourceforge.net/
PHPMailer Mailing list: http://lists.sourceforge.net/lists/listinfo/phpmailer-general
PHPMailer Documentation: http://phpmailer.sourceforge.net/phpdoc/phpmailer.html