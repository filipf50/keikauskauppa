Install:
Upload the extra language .xml file into: vqmod/xml/

PS: if you find any errors or improvements to these language files please send them to: .
info@opencart-templates.co.uk 