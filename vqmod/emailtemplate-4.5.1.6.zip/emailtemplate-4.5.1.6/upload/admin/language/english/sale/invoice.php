<?php
# Anything in here with the same name, will overwrite order.php

$_['text_to']           = 'BILLING';
$_['text_ship_to']       = 'SHIPPING';

$_['column_product']     = '<b>PRODUCT</b>';
$_['column_model']       = '<b>MODEL</b>';
$_['column_quantity']    = '<b>QUANTITY</b>';
$_['column_price']       = '<b>PRICE</b>';
$_['column_total']       = '<b>TOTAL</b>';

?>