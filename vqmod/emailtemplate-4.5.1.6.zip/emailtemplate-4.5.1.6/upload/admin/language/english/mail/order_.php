<?php
# Anything in here with the same name will overwrite the main file without underscore. 

$_['text_download']           = 'Downloads'; 
$_['text_model']              = 'Model'; 
$_['text_order']              = 'Order ID:ds'; 
$_['text_price']              = 'Price'; 
$_['text_product']            = 'Product'; 
$_['text_total']              = 'Total'; 

?>