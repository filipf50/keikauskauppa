<?php 
# Anything in here with the same name will overwrite the main file without underscore.  

$_['entry_enquiry_customer']  = 'Thank you for your enquiry, here is a copy of your message';
$_['ip_address']  = 'IP Address:';
$_['user_agent']  = 'User Agent:';
$_['remote_host']  = 'Remote Host:';
$_['accept_language']  = 'Accept Language:';

?>