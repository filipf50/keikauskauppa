<?php 
# Anything in here with the same name will overwrite the main file without underscore.  

$_['heading_unsubscribe']   = 'Newsletter Unsubscribe';
$_['success_unsubscribe']   = '<p>Success: The E-Mail Address %s has been successfully unsubscribed from our newsletter!</p>';
$_['error_unsubscribe']     = '<p>Warning: The E-Mail Address was not found in our records, please try again!</p>';

?>