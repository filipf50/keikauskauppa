<?php 
# Anything in here with the same name will overwrite the main file without underscore.  

$_['text_account_login'] = 'VISIT OUR SITE NOW';
$_['text_address']  	= 'Address:';
$_['text_approve'] 		= 'Customer account requires approval, click the link below to approve:';
$_['text_company'] 		= 'Company';
$_['text_customer_group'] = 'Customer group';
$_['text_email']  		= 'Email';
$_['text_fax'] 			= 'Fax';
$_['text_mail_welcome'] = 'Welcome %s and thank you for registering at %s!';
$_['text_name']  		= 'Name';
$_['text_newsletter'] 	= 'Newsletter';
$_['text_password'] 	= 'Password';
$_['text_telephone']	= 'Telephone';

?>