<?php 
# Anything in here with the same name will overwrite the main file without underscore.  

$_['text_login']  = 'Log in by visiting:';
$_['text_new_password']  = 'Your new password is:';

?>