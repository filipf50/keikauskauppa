<?php
# Anything in here with the same name will overwrite the main file without underscore.

$_['text_address'] = 'Address:';
$_['text_affiliate'] = 'Affiliate:';
$_['text_customer_group'] = 'Customer group:';
$_['text_id'] = 'ID';
$_['text_new_subject_admin'] = 'Order %s - %s (%s)'; // 1.Order ID, 2.Customer Name, 3.Store Name
$_['text_order_link'] = 'To view this order click on the link below:';
$_['text_sku'] = 'SKU';
$_['text_stock_quantity'] = 'Quantity remaining';
$_['text_product_options'] = 'Options';

?>