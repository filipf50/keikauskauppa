<?php
/*
 * Delete all files/folders for professional HTMl email template.
 * 
 * Move this file into your store root
 *
 */
set_time_limit (0);
error_reporting(E_ALL ^ E_NOTICE ^E_WARNING);
ini_set("display_errors" , 1);

if(isset($_POST['confirm'])){
	$files = array(
		'\admin\controller\module\emailtemplate.php',
		
		'\admin\language\english\module\emailtemplate.php',
		
		'\admin\model\module\emailtemplate.php',
		'\admin\model\module\emailtemplate',
	
		//'\admin\view\image\colorpicker', Color picker unsafe to delete may be used by other modules
		//'\admin\view\javascript\jquery\colorpicker.js',
		//'\admin\view\stylesheet\colorpicker.css',
		
		'\admin\view\javascript\highlight',
		
		'\admin\view\stylesheet\module\emailtemplate.css',
	
		'\admin\view\template\mail\affiliate_approve.tpl',
		'\admin\view\template\mail\affiliate_transaction.tpl',
		'\admin\view\template\mail\customer_approve.tpl',
		'\admin\view\template\mail\customer_insert.tpl',
		'\admin\view\template\mail\customer_reward.tpl',
		'\admin\view\template\mail\customer_transaction.tpl',
		'\admin\view\template\mail\customer_voucher.tpl',
		'\admin\view\template\mail\demo.tpl',
		'\admin\view\template\mail\order_update.tpl',
		'\admin\view\template\mail\return_history.tpl',
	
		'\admin\view\template\module\emailtemplate',
	
		'\catalog\view\theme\default\template\mail\_mail.tpl',
		'\catalog\view\theme\default\template\mail\affiliate_forgotten.tpl',
		'\catalog\view\theme\default\template\mail\affiliate_register.tpl',
		'\catalog\view\theme\default\template\mail\affiliate_register_admin.tpl',
		'\catalog\view\theme\default\template\mail\contact.tpl',
		'\catalog\view\theme\default\template\mail\contact_admin.tpl',
		'\catalog\view\theme\default\template\mail\customer_forgotten.tpl',
		'\catalog\view\theme\default\template\mail\customer_register.tpl',
		'\catalog\view\theme\default\template\mail\customer_register_admin.tpl',
		'\catalog\view\theme\default\template\mail\ebay_order_confirm.tpl',
		'\catalog\view\theme\default\template\mail\ebay_order_update.tpl',
		'\catalog\view\theme\default\template\mail\ebay_stock_report.tpl',
		'\catalog\view\theme\default\template\mail\openbay_order_admin.tpl',
		'\catalog\view\theme\default\template\mail\order_admin.tpl',
		'\catalog\view\theme\default\template\mail\order_customer.tpl',
		'\catalog\view\theme\default\template\mail\order_customer_wide.tpl',
		'\catalog\view\theme\default\template\mail\play_order_update.tpl',
		'\catalog\view\theme\default\template\mail\product_review.tpl',
		'\catalog\view\theme\default\template\mail\return_admin.tpl',
		'\catalog\view\theme\default\template\mail\voucher_customer.tpl',
	
		'\image\data\emailtemplate',
	
		'\system\library\email_template.php',
		
		'\system\library\shared\html_dom_parser.php',
		
		'\system\library\shared\tcpdf',
	
		'\vqmod\xml\emailtemplate.xml',
		'\vqmod\xml\emailtemplate_admin.xml',
		'\vqmod\xml\emailtemplate_languages.xml',
		'\vqmod\vqcache',
		'\vqmod\mods.cache'
	);
	
	/**
     * Delete a file or recursively delete a directory
     *
     * @param string $str Path to file or directory
     */
    function recursiveDelete($str){
        if(is_file($str)){
            return @unlink($str);
        }
        elseif(is_dir($str)){
            $scan = glob(rtrim($str,'/').'/*');
            foreach($scan as $index=>$path){
                recursiveDelete($path);
            }
            return @rmdir($str);
        }
    }
	
	foreach($files as $file){
		recursiveDelete(dirname(__FILE__) . $file);		
	}
	
	echo 'Done!';		
	exit;
}
?>

<form action="" method="post">
	<fieldset>		
		<label>
			<input type="checkbox" name="confirm" value="1" />
			Confirm delete all extension files
		</label>
		<br />
		<input type="submit" value="Yes" />
	</fieldset>
</form>