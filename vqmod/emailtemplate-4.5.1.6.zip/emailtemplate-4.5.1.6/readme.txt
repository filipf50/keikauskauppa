Thank you for purchasing this extension and please dont forget to rate it (click the starts)  
www.opencart.com/index.php?route=account/extension/update&extension_id=2221 

Please read the Documentation for further information
mystore.com/admin/index.php?route=module/emailtemplate/docs