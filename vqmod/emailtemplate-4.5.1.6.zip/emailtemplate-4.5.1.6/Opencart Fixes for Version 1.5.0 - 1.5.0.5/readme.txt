1. Upload this extra vqmod file into: vqmod/xml
2. Make sure you follow the extra steps in the Documentation -> Install.